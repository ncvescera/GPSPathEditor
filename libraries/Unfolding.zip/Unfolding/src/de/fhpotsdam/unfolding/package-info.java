/**
 * Contains the main UnfoldingMap class, and all sub-packages.
 */

package de.fhpotsdam.unfolding;

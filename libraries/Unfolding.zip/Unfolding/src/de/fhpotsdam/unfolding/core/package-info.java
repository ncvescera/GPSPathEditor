/**
 * Internal stuff.
 */

package de.fhpotsdam.unfolding.core;
